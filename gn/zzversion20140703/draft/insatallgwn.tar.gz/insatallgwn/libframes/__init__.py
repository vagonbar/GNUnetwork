#!/usr/bin/env python
# -*- coding: utf-8 -*-

# libframes : frames library, version 2

'''MAC Frames library, version 2.

@version: 2

@author: Victor Gonzalez-Barbone
@organization: Departamento de Telecomunicaciones, Instituto de Ingeniería Eléctrica, Facultad de Ingeniería, Universidad de la República, Uruguay.
@copyright: Universidad de la República, Uruguay.
@license: to be determined.
@contact: vagonbar at fing. edu.uy
'''

