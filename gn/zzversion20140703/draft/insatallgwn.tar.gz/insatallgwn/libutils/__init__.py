#!/usr/bin/env python
# -*- coding: utf-8 -*

'''Utility classes and functions for GNU network.
'''


